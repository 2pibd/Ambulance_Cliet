package com.twopibd.dactarbari.ambulance.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.twopibd.dactarbari.ambulance.R;

public class LocationPickActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_pick);
    }
}
