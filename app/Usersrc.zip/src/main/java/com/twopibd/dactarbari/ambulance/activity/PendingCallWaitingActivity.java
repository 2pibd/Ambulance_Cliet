package com.twopibd.dactarbari.ambulance.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.twopibd.dactarbari.ambulance.R;

public class PendingCallWaitingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_call_waiting);
    }
}
